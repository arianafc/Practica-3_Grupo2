﻿using System;
using System.Linq;
using System.Web.Mvc;
using Practica3.EF;

namespace Practica3.Controllers
{
    public class RegistroController : Controller
    {
        private readonly PracticaS12Entities db = new PracticaS12Entities();

        // GET: Registro
        public ActionResult Index()
        {
            ViewBag.ComprasPendientes = new SelectList(
                db.Principal
                  .Where(p => p.Estado == "Pendiente")
                  .Select(p => new { p.Id_Compra, Texto = p.Id_Compra + " - " + p.Descripcion }),
                "Id_Compra", "Texto");

            return View("~/Views/Sistema/Registro.cshtml");
        }

        // POST: Registro
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(long Id_Compra, decimal Monto)
        {
            // Volver a poblar el dropdown si hay error
            ViewBag.ComprasPendientes = new SelectList(
                db.Principal
                  .Where(p => p.Estado == "Pendiente")
                  .Select(p => new { p.Id_Compra, Texto = p.Id_Compra + " - " + p.Descripcion }),
                "Id_Compra", "Texto", Id_Compra);

            var compra = db.Principal.FirstOrDefault(p => p.Id_Compra == Id_Compra);

            if (compra == null)
            {
                ModelState.AddModelError("", "Compra no encontrada.");
                return View("~/Views/Sistema/Registro.cshtml");
            }
            if (Monto <= 0)
            {
                ModelState.AddModelError("", "El abono debe ser mayor a 0.");
                return View("~/Views/Sistema/Registro.cshtml");
            }
            if (Monto > compra.Saldo)
            {
                ModelState.AddModelError("", "El abono no puede ser mayor al saldo.");
                return View("~/Views/Sistema/Registro.cshtml");
            }

            // Registrar abono
            var abono = new Abonos
            {
                Id_Compra = compra.Id_Compra,
                Monto = Monto,
                Fecha = DateTime.Now
            };
            db.Abonos.Add(abono);

            // Actualizar saldo y estado
            compra.Saldo = Math.Round(compra.Saldo - Monto, 5);
            if (compra.Saldo == 0m)
                compra.Estado = "Cancelado";

            db.SaveChanges();

            // Redirigir a Consulta
            return RedirectToAction("Index", "Consulta");
        }

        // (Opcional) AJAX para mostrar saldo/precio al elegir compra
        [HttpGet]
        public JsonResult GetSaldo(long id)
        {
            var data = db.Principal
                         .Where(p => p.Id_Compra == id)
                         .Select(p => new { saldo = p.Saldo, precio = p.Precio })
                         .FirstOrDefault();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}
